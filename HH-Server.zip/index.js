const express = require('express');
const bodyParser = require('body-parser');
const fs = require("fs");
const cors = require('cors');

const app = express();
const jsonParser = bodyParser.json();

const corsOptions={
  origin: '*',
  optionSuccessStatus: 200
}
app.use(cors(corsOptions));

const data = require('./data.json');

app.use(bodyParser.json());

app.get('/getData', (req, res) => {
  console.log('getting data');
  res.send(data);
});

app.post('/postData', (req, res) => {
  console.log('posting data');
  data.push(req.body);
  fs.writeFile("./data.json", JSON.stringify(data), (err) => {
    if (err) throw err;
  })
  res.send(data);
});

app.listen(3000, () => {
  console.log('server started');
});