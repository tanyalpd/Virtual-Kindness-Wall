let talk = [];
$(function() {
  loadTalk();
});

function sendBtn() {
  let sendMsg = document.getElementById('sendMsg');
  let textBubble = document.getElementById('textBubble');  
  $.ajax({
    url: 'https://Chat-Server.tanyalertpradis.repl.co/postData',
    method: 'post',
    dataType: 'json',
    contentType: 'application/json',
    data: JSON.stringify({
      "text": sendMsg.value,
    }),
  })
  .done(function( data ) {
    talk = data;
    drawTalk();
  })
  .fail(function(xhr) {
    alert("Cannot save data to the server!");
  });
}

function drawTalk() {
  let textBubble = document.getElementById('textBubble');  
  textBubble.querySelectorAll('*').forEach(n => n.remove());
  for (let i=0; i< talk.length; i++) {
    let sendMsg = document.createElement('div');
    sendMsg.classList.add('bubble');    
    sendMsg.innerHTML = talk[i].text;
    textBubble.appendChild(sendMsg);
  }
}

function loadTalk() {
  $.ajax({
    url: "https://Chat-Server.tanyalertpradis.repl.co/getData",
    method: 'get',
  })
  .done(function(data){
    talk = data;
    drawTalk();
    })
    .fail(function(xhr, t, e) {
      alert("Cannot load data!" + xhr.status);
    }
  );
}