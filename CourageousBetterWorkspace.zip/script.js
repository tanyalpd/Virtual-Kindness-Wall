function submitBtn1 () {
  let name = document.getElementById('txtName');
  let message = document.getElementById('txtMsg');
  let wall = document.getElementById('wall');

  if (message.value != '' && name.value != '') {
    let div = document.createElement('div');
      div.classList.add('mosaic');
      div.innerHTML = name.value + ': ' + message.value;
      wall.appendChild(div); 
   } else {
      alert('Name and Message is required');
    }
}


let notes = [];
$(function() {
  loadNotes();
});

function submitBtn() {
  let name = document.getElementById('txtName');
  let message = document.getElementById('txtMsg');
  let wall = document.getElementById('wall');  
  $.ajax({
    url: 'https://HH-Server.tanyalertpradis.repl.co/postData',
    method: 'post',
    dataType: 'json',
    contentType: 'application/json',
    data: JSON.stringify({
      "name": name.value,
      "message": message.value
    }),
  })
  .done(function( data ) {
    notes = data;
    drawNotes();
  })
  .fail(function(xhr) {
    alert("Cannot save data to the server!");
  });
}

function drawNotes() {
  let wall = document.getElementById('wall');  
  wall.querySelectorAll('*').forEach(n => n.remove());
  for (let i=0; i< notes.length; i++) {
    let card = document.createElement('div');
    let randomColor = generateRandomColor();
    card.style.backgroundColor = randomColor;
    card.classList.add('card');    
    card.classList.add('mosaic');
    let head = document.createElement('div');
    head.classList.add('card');
    head.classList.add('card-header');
    head.style.backgroundColor = randomColor;
    head.innerHTML = notes[i].name;
    let body = document.createElement('div');
    body.classList.add('card');
    body.classList.add('card-body');
    body.innerHTML = notes[i].message;
    card.appendChild(head);
    card.appendChild(body);
    wall.appendChild(card); 
  }
}

function generateRandomColor() {
  return 'rgba(' + Math.floor((Math.random() * 255) + 20) + "," +
  Math.floor((Math.random() * 255) + 20) + "," +
  Math.floor((Math.random() * 255) + 20) + "," +
  "0.2)";
}

function loadNotes() {
  $.ajax({
    url: "https://HH-Server.tanyalertpradis.repl.co/getData",
    method: 'get',
  })
  .done(function(data){
    notes = data;
    drawNotes();
    })
    .fail(function(xhr, t, e) {
      alert("Cannot load data!" + xhr.status);
    }
  );
}
